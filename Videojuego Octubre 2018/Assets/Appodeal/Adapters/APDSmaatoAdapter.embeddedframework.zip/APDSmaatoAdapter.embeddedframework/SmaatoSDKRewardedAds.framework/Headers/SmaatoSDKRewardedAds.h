//
//  SmaatoSDKRewardedAds.h
//  SmaatoSDKRewardedAds
//
//  Created by Smaato Inc on 23.05.18.
//  Copyright © 2018 Smaato Inc. All rights reserved.￼
//  Licensed under the Smaato SDK License Agreement￼
//  https://www.smaato.com/sdk-license-agreement/
//

#import <SmaatoSDKCore/SmaatoSDKCore.h>
#import <SmaatoSDKRewardedAds/SMARewardedInterstitial+KeyValueTargeting.h>
#import <SmaatoSDKRewardedAds/SMARewardedInterstitial+MediationAdapter.h>
#import <SmaatoSDKRewardedAds/SmaatoSDK+RewardedAds.h>

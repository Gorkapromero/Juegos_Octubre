//
//  SmaatoSDKOpenMeasurementFramework.h
//  SmaatoSDKOpenMeasurement
//
//  Created by Smaato Inc on 24.06.19.
//  Copyright © 2019 Smaato. All rights reserved.￼
//  Licensed under the Smaato SDK License Agreement￼
//  https://www.smaato.com/sdk-license-agreement/
//

#import <Foundation/Foundation.h>

static NSString *const kSmaatoSDKOpenMeasurementFramework =
    @"SmaatoSDKOpenMeasurementFramework_I_am_mandatory_dependency_for_SmaatoSDK_Please_add_me";

@interface SmaatoSDKOpenMeasurementFramework_I_am_mandatory_dependency_for_SmaatoSDK_Please_add_me : NSObject

+ (void)hello;

@end

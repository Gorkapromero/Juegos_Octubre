//
//  SMAAdRequestParams.h
//  SmaatoSDKCore
//
//  Created by Smaato Inc on 01.11.19.
//  Copyright © 2019 Smaato Inc. All rights reserved.
//

#import <Foundation/Foundation.h>

/**
 Optional parameters for advanced ad requests.
*/
@interface SMAAdRequestParams : NSObject

/// Unified Bidding unique identifier (see Smaato's Unified Bidding Publisher Setup (iOS))
@property (nonatomic, copy, nullable) NSString *ubUniqueId;

@end

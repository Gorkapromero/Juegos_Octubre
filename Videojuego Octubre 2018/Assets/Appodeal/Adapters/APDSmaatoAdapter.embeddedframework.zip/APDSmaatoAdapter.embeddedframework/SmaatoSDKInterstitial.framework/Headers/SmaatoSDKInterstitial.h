//
//  SmaatoSDKInterstitial.h
//  SmaatoSDKInterstitial
//
//  Created by Smaato Inc on 09/03/2018.
//  Copyright © 2018 Smaato Inc. All rights reserved.￼
//  Licensed under the Smaato SDK License Agreement￼
//  https://www.smaato.com/sdk-license-agreement/
//

#import <SmaatoSDKInterstitial/SMAInterstitial+KeyValueTargeting.h>
#import <SmaatoSDKInterstitial/SMAInterstitial+MediationAdapter.h>
#import <SmaatoSDKInterstitial/SMAInterstitial.h>
#import <SmaatoSDKInterstitial/SmaatoSDK+Interstitial.h>

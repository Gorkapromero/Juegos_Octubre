#import "AdColonyTypes.h"

/**
 Typed error for AdColony ad requests.
 */
@interface AdColonyAdRequestError : NSError

@end
